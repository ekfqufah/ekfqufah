package com.javalec.team.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.javalec.team.dto.CartDto;
import com.javalec.team.dto.GoodsDto;
import com.javalec.team.service.CartService;
import com.javalec.team.service.GoodsService;




@Controller
public class GoodsController {
	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private GoodsService goodsService;
	
	@Autowired
	private CartController cartController;
	
	
	
	@RequestMapping(value = "/addGoods", method = RequestMethod.GET)
	public String upload2(Locale locale, Model model) {
		return "goods/addGoods";
	}

	@RequestMapping(value = "upload")
	public String requestupload2(MultipartHttpServletRequest mtfRequest) {
		List<MultipartFile> fileList = mtfRequest.getFiles("file");
		String g_name = mtfRequest.getParameter("g_name");
		String g_price = mtfRequest.getParameter("g_price");
		System.out.println("src value : " + g_name);
		System.out.println("src value : " + g_price);

		String path = "C:\\test\\";
		
		HashMap<String, String> param = new HashMap<String, String>();
		param.put("g_name", g_name);
		param.put("g_price", g_price);
		goodsService.insertGoods(param);
		GoodsDto dto = goodsService.getGoodsGcode();
		int g_code = dto.getG_code();
		param.put("g_code", Integer.toString(g_code));
		int count = 0;
		
		for (MultipartFile mf : fileList) {
			 count ++;
			String originFileName = mf.getOriginalFilename(); // ���� ���� ��
			long fileSize = mf.getSize(); // ���� ������

			System.out.println("originFileName : " + originFileName);
			System.out.println("fileSize : " + fileSize);
			
			String filename = System.currentTimeMillis() + originFileName;
			String safeFile = path +filename;
			
			param.put("img_origin", originFileName);
			
			if(count == 1) {
				param.put("img_1", filename);
				param.put("img_2", "");
			}else {
				param.put("img_1", "");
				param.put("img_2", filename);
			}
			
			
			try {
				mf.transferTo(new File(safeFile));
				goodsService.insertGoodsImg(param);
				
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return "redirect:/";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void getGoods(@RequestParam HashMap<String, String> param, Model model) {
		GoodsDto goodsdto = goodsService.getGoods(param);		
		model.addAttribute("goods",goodsdto);
	}
	
	@RequestMapping("/mainview")
	public String mainview(HttpServletRequest request) {
		return "mainview";
	}
	
	@RequestMapping("goodsDisplay")
	public String goodsDisplay(@RequestParam HashMap<String, String> param,Model model) {
		//System.out.println("������?@@@@@@@@@@@@@@");
		getGoods(param,model);
		return "goods/goodsDisplay";
	}
	
	
	@RequestMapping("/buy")
	public String buy(@RequestParam HashMap<String, String> param,HttpServletRequest request,Model model) {
		String[] cart_listc_code = null;
		
		if(request.getParameterValues("cart_listc_code") != null) {
			ArrayList<CartDto> cartlist = new ArrayList<CartDto>();
			cart_listc_code = request.getParameterValues("cart_listc_code");
			ArrayList<CartDto> buylist = cartController.cartlistbuy(cart_listc_code);
			for (int i = 0; i < cart_listc_code.length; i++) {
				int price = buylist.get(i).getG_price()*buylist.get(i).getC_amount();
				buylist.get(i).setG_price(price);
				param.put("c_code", cart_listc_code[i]);
				param.put("g_code",Integer.toString( buylist.get(i).getC_amount()));
				param.put("c_amount", Integer.toString(buylist.get(i).getC_amount()));
				param.put("g_price", Integer.toString(price));
				//System.out.println(param.get("c_code"));
				cartController.deleteCart(param, null);
				goodsService.insertBuy(param);
			}
			model.addAttribute("cartlist",buylist);
			return "mainview";
		}
		
	
		
		
		if(cart_listc_code == null) {
			int price = Integer.parseInt(param.get("g_price"))*Integer.parseInt(param.get("c_amount"));
			param.put("g_price", Integer.toString(price));
			goodsService.insertBuy(param);
		}
		return "mainview";	
	}
	
	
	
	
	
	
	

}
